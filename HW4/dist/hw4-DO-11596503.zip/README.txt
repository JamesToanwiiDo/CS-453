***Instructions***
1. Unzip the compressed file and launch the Terminal within the extracted folder
2. Type the following into Terminal to install all the dependencies: npm install -d
3. Make sure that MongoDB service is installed and running (Please refer to this link for further instructions: https://docs.mongodb.com/manual/installation/)
4. To run the server file: node server.js
5. Open your web browser and go to: localhost:3000/